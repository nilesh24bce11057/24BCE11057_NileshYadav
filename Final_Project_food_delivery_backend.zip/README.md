# Food Delivery Backend API

This is a backend project for a food delivery system. It is built using Node.js, Express, and MongoDB. It has 13 modules to handle users, restaurants, menu items, orders, cart, delivery agents, reviews, kitchen orders, inventory, offers, localities, categories, and preferences.

## Tech Stack
- **Node.js & Express**: To handle the server and API routing.
- **MongoDB & Mongoose**: Database to store all the data.
- **Swagger**: To test and check the APIs easily using a web browser.

---

## 13 Project Modules

Here is a simple explanation of what each module does in the code:

1. **User**: Stores information about users who order food (name, email, phone, password, address, and order history).
2. **Restaurant**: Details of the restaurants (name, type of food, address, rating, owner ID, locality, and menu items list).
3. **MenuItem**: Food items belonging to a restaurant (name, description, price, food category, availability, tags like 'veg' or 'spicy', and restaurant ID).
4. **Order**: Orders made by users (user ID, restaurant ID, items list with quantity/price, status like 'placed'/'preparing'/'delivered', total amount, payment mode, and delivery agent).
5. **Cart**: A temporary cart for a user to save items before buying (user ID, restaurant ID, and items with quantities).
6. **DeliveryAgent**: Delivery riders (name, phone, vehicle type, availability, current order, and history of completed orders).
7. **Review**: Ratings and feedback given by users for a restaurant or food item (rating from 1 to 5, and comment).
8. **KitchenOrder**: Internal kitchen orders for restaurants to track cooking (order ID, status like 'cooking' or 'ready', and cooking times).
9. **Inventory**: Raw materials or stock levels at each restaurant (ingredient name, quantity, unit like kg/pieces, and a warning level when stock is low).
10. **Offer**: Discount coupon codes for users (promo code, discount %, restaurant ID, expiry date, and list of users who used it).
11. **Locality**: Delivery areas/locations (area name, city, zip code, and restaurants operating in that area).
12. **Category**: Groups of menu items like Starters, Main Course, Desserts (name, description, and list of food items).
13. **Preference**: User choices for food (dietary habit like veg/non-veg, spice preference, favorite cuisines, and allergies).

---

## Mongoose Table Relationships

The database tables (collections) link to each other in these ways:

### 1. One-to-One Relationships
- **Restaurant owner**: A Restaurant connects to a User (the owner) using `owner_id`.
- **User Cart**: A Cart connects to a User using `user_id` (one cart per user).
- **User Preference**: A Preference connects to a User using `user_id` (one profile preference per user).

### 2. One-to-Many Relationships
- **User and Orders**: One User can make many Orders.
- **Restaurant and Menu Items**: One Restaurant has many Menu Items.
- **Locality and Restaurants**: One Locality can have many Restaurants.
- **Restaurant and Reviews**: One Restaurant gets many Reviews from different users.
- **Restaurant and Inventory**: One Restaurant has many Inventory items.

### 3. Many-to-Many Relationships
- **Order and Menu Items**: An Order contains many Menu Items, and a Menu Item can be part of many different Orders (stored inside `items` array inside Order).
- **Category and Menu Items**: A Category contains many Menu Items, and a Menu Item can belong to multiple categories.

---

## How to Set Up the Project

### Prerequisites
Make sure you have Node.js and MongoDB installed on your computer.

### Steps
1. Open this project folder in your terminal.
2. Install the required Node packages:
   ```bash
   npm install
   ```
3. Set up environment variables. Look at the `.env.example` file. Create a file named `.env` in the root folder and add your port and MongoDB URL:
   ```env
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/food_delivery
   ```
4. Start the server:
   ```bash
   node server.js
   ```
   You should see these messages in the terminal:
   `Server running on http://localhost:5000`
   `MongoDB Connected Successfully`

---

## How to Check the APIs (Swagger UI)

We have integrated Swagger to make testing simple. You do not need Postman. 

1. Start your local server (`node server.js`).
2. Open your web browser and go to:
   **http://localhost:5000/api-docs**
3. You will see a beautiful page listing all the API endpoints for the 13 modules.
4. You can expand any endpoint (like `GET /api/users` or `POST /api/users/register`), click **"Try it out"**, fill in the details, and click **"Execute"** to see live results from the database.

---

## Project Structure & Screenshots
- **/config**: Database connection code.
- **/models**: Mongoose schemas for the 13 modules.
- **/routes**: API routes for handling CRUD operations.
- **/screenshots**: Folder to save your Swagger UI and MongoDB Compass screenshots.
- **server.js**: The main entry file.
- **swagger.js**: Swagger documentation config.
- **zip-project.ps1**: PowerShell script to zip this project for submission.
