const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger');

dotenv.config();
connectDB();

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/users',           require('./routes/users'));
app.use('/api/restaurants',     require('./routes/restaurants'));
app.use('/api/menu',            require('./routes/menuItems'));
app.use('/api/orders',          require('./routes/orders'));
app.use('/api/cart',            require('./routes/cart'));
app.use('/api/delivery-agents', require('./routes/deliveryAgents'));
app.use('/api/reviews',         require('./routes/reviews'));
app.use('/api/kitchen',         require('./routes/kitchen'));
app.use('/api/inventory',       require('./routes/inventory'));
app.use('/api/offers',          require('./routes/offers'));
app.use('/api/localities',      require('./routes/localities'));

// Swagger
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.get('/', (req, res) => res.send('Food Delivery API Running'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
app.use('/api/categories',   require('./routes/categories'));
app.use('/api/preferences',  require('./routes/preferences'));
