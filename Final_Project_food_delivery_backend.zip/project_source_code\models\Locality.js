const mongoose = require('mongoose');

const localitySchema = new mongoose.Schema({
  area_name:   { type: String, required: true },
  pincode:     { type: String, required: true, unique: true },
  city:        { type: String, required: true },
  restaurants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }]
}, { timestamps: true });

module.exports = mongoose.model('Locality', localitySchema);