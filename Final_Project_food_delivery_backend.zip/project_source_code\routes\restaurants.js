const express = require('express');
const router = express.Router();
const Restaurant = require('../models/Restaurant');
const Locality = require('../models/Locality');

/**
 * @swagger
 * /api/restaurants:
 *   get:
 *     summary: Get all restaurants
 *     responses:
 *       200:
 *         description: List of restaurants
 */
router.get('/', async (req, res) => {
  try {
    const restaurants = await Restaurant.find().populate('locality_id').populate('menu_items');
    res.json(restaurants);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/restaurants:
 *   post:
 *     summary: Add a new restaurant
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               cuisine_type:
 *                 type: string
 *               address:
 *                 type: string
 *               rating:
 *                 type: number
 *               owner_id:
 *                 type: string
 *               locality_id:
 *                 type: string
 *     responses:
 *       201:
 *         description: Restaurant created
 */
router.post('/', async (req, res) => {
  try {
    const restaurant = new Restaurant(req.body);
    await restaurant.save();
    if (req.body.locality_id) {
      await Locality.findByIdAndUpdate(req.body.locality_id, { $push: { restaurants: restaurant._id } });
    }
    res.status(201).json(restaurant);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/restaurants/nearby/{pincode}:
 *   get:
 *     summary: Get restaurants near a pincode
 *     parameters:
 *       - in: path
 *         name: pincode
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Nearby restaurants
 */
router.get('/nearby/:pincode', async (req, res) => {
  try {
    const locality = await Locality.findOne({ pincode: req.params.pincode });
    if (!locality) return res.status(404).json({ message: 'Locality not found' });
    const restaurants = await Restaurant.find({ locality_id: locality._id });
    res.json(restaurants);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/restaurants/famous/{pincode}:
 *   get:
 *     summary: Get top rated restaurants in a pincode
 *     parameters:
 *       - in: path
 *         name: pincode
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Famous restaurants
 */
router.get('/famous/:pincode', async (req, res) => {
  try {
    const locality = await Locality.findOne({ pincode: req.params.pincode });
    if (!locality) return res.status(404).json({ message: 'Locality not found' });
    const restaurants = await Restaurant.find({ locality_id: locality._id }).sort({ rating: -1 }).limit(5);
    res.json(restaurants);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/restaurants/{id}:
 *   put:
 *     summary: Update a restaurant
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Restaurant updated
 *   delete:
 *     summary: Delete a restaurant
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Restaurant deleted
 */
router.put('/:id', async (req, res) => {
  try {
    const restaurant = await Restaurant.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(restaurant);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await Restaurant.findByIdAndDelete(req.params.id);
    res.json({ message: 'Restaurant deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;