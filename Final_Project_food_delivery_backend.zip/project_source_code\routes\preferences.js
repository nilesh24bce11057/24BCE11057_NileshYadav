const express = require('express');
const router = express.Router();
const Preference = require('../models/Preference');

/**
 * @swagger
 * /api/preferences:
 *   post:
 *     summary: Create user preference
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               user_id:
 *                 type: string
 *               food_type:
 *                 type: string
 *               spice_level:
 *                 type: string
 *               favourite_cuisines:
 *                 type: array
 *                 items:
 *                   type: string
 *               allergies:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       201:
 *         description: Preference created
 */
router.post('/', async (req, res) => {
  try {
    const preference = new Preference(req.body);
    await preference.save();
    res.status(201).json(preference);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/preferences/{userId}:
 *   get:
 *     summary: Get preference for a user
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User preference
 */
router.get('/:userId', async (req, res) => {
  try {
    const preference = await Preference.findOne({ user_id: req.params.userId }).populate('user_id');
    res.json(preference);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/preferences/{userId}:
 *   put:
 *     summary: Update user preference
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               food_type:
 *                 type: string
 *               spice_level:
 *                 type: string
 *               favourite_cuisines:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       200:
 *         description: Preference updated
 */
router.put('/:userId', async (req, res) => {
  try {
    const preference = await Preference.findOneAndUpdate(
      { user_id: req.params.userId },
      req.body,
      { new: true }
    );
    res.json(preference);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

module.exports = router;