const mongoose = require('mongoose');

const preferenceSchema = new mongoose.Schema({
  user_id:         { type: mongoose.Schema.Types.ObjectId, ref: 'User', unique: true, required: true }, // One to One
  food_type:       { type: String, enum: ['veg', 'non-veg', 'both'], default: 'both' },
  spice_level:     { type: String, enum: ['mild', 'medium', 'spicy'], default: 'medium' },
  favourite_cuisines: [String],
  allergies:       [String]
}, { timestamps: true });

module.exports = mongoose.model('Preference', preferenceSchema);