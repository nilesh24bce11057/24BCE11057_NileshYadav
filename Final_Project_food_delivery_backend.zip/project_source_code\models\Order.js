const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  user_id:            { type: mongoose.Schema.Types.ObjectId, ref: 'User',          required: true },
  restaurant_id:      { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant',    required: true },
  delivery_agent_id:  { type: mongoose.Schema.Types.ObjectId, ref: 'DeliveryAgent' },
  items: [{
    menu_item_id: { type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem' }, // Many to Many
    quantity:     Number,
    price:        Number
  }],
  status:       { type: String, enum: ['placed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled'], default: 'placed' },
  total_amount: { type: Number, required: true },
  payment_mode: { type: String, enum: ['cash', 'online', 'card'], default: 'cash' },
  placed_at:    { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);