const express = require('express');
const router = express.Router();
const Inventory = require('../models/Inventory');

/**
 * @swagger
 * /api/inventory/{restaurantId}:
 *   get:
 *     summary: Get inventory for a restaurant
 *     parameters:
 *       - in: path
 *         name: restaurantId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Inventory list
 */
router.get('/:restaurantId', async (req, res) => {
  try {
    const items = await Inventory.find({ restaurant_id: req.params.restaurantId }).populate('linked_menu_items');
    res.json(items);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/inventory:
 *   post:
 *     summary: Add inventory item
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               restaurant_id:
 *                 type: string
 *               ingredient_name:
 *                 type: string
 *               quantity_available:
 *                 type: number
 *               unit:
 *                 type: string
 *                 enum: ['kg', 'litres', 'pieces']
 *               reorder_level:
 *                 type: number
 *               linked_menu_items:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       201:
 *         description: Inventory item added
 */
router.post('/', async (req, res) => {
  try {
    const item = new Inventory(req.body);
    await item.save();
    res.status(201).json(item);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/inventory/{id}:
 *   put:
 *     summary: Update inventory item
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Inventory updated
 */
router.put('/:id', async (req, res) => {
  try {
    const item = await Inventory.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(item);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/inventory/{restaurantId}/low-stock:
 *   get:
 *     summary: Get low stock ingredients
 *     parameters:
 *       - in: path
 *         name: restaurantId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Low stock items
 */
router.get('/:restaurantId/low-stock', async (req, res) => {
  try {
    const items = await Inventory.find({
      restaurant_id: req.params.restaurantId,
      $expr: { $lte: ['$quantity_available', '$reorder_level'] }
    });
    res.json(items);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;