const express = require('express');
const router = express.Router();
const MenuItem = require('../models/MenuItem');
const Restaurant = require('../models/Restaurant');

/**
 * @swagger
 * /api/menu/{restaurantId}:
 *   get:
 *     summary: Get menu items for a restaurant
 *     parameters:
 *       - in: path
 *         name: restaurantId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Menu items list
 */
router.get('/:restaurantId', async (req, res) => {
  try {
    const items = await MenuItem.find({ restaurant_id: req.params.restaurantId });
    res.json(items);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/menu:
 *   post:
 *     summary: Add a menu item
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               description:
 *                 type: string
 *               price:
 *                 type: number
 *               category:
 *                 type: string
 *                 enum: ['Starters', 'Main Course', 'Desserts', 'Beverages', 'Snacks']
 *               is_available:
 *                 type: boolean
 *               tags:
 *                 type: array
 *                 items:
 *                   type: string
 *               restaurant_id:
 *                 type: string
 *     responses:
 *       201:
 *         description: Menu item added
 */
router.post('/', async (req, res) => {
  try {
    const item = new MenuItem(req.body);
    await item.save();
    await Restaurant.findByIdAndUpdate(req.body.restaurant_id, { $push: { menu_items: item._id } });
    res.status(201).json(item);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/menu/{id}:
 *   put:
 *     summary: Update a menu item
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Menu item updated
 *   delete:
 *     summary: Delete a menu item
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Menu item deleted
 */
router.put('/:id', async (req, res) => {
  try {
    const item = await MenuItem.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(item);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await MenuItem.findByIdAndDelete(req.params.id);
    res.json({ message: 'Menu item deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;