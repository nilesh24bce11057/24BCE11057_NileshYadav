const mongoose = require('mongoose');

const menuItemSchema = new mongoose.Schema({
  name:          { type: String, required: true },
  description:   String,
  price:         { type: Number, required: true },
  category:      { type: String, enum: ['Starters', 'Main Course', 'Desserts', 'Beverages', 'Snacks'] },
  is_available:  { type: Boolean, default: true },
  tags:          [String], // ['veg', 'spicy', 'bestseller']
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' } // Many to One
}, { timestamps: true });

module.exports = mongoose.model('MenuItem', menuItemSchema);