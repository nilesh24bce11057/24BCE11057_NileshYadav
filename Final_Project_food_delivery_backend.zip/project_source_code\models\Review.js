const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
  user_id:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
  menu_item_id:  { type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem' },
  rating:        { type: Number, required: true, min: 1, max: 5 },
  comment:       { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Review', reviewSchema);