const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');

/**
 * @swagger
 * /api/cart/{userId}:
 *   get:
 *     summary: Get cart for a user
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Cart details
 */
router.get('/:userId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user_id: req.params.userId }).populate('items.menu_item_id');
    res.json(cart);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/cart/{userId}/add:
 *   post:
 *     summary: Add item to cart
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               restaurant_id:
 *                 type: string
 *               menu_item_id:
 *                 type: string
 *               quantity:
 *                 type: number
 *     responses:
 *       200:
 *         description: Item added to cart
 */
router.post('/:userId/add', async (req, res) => {
  try {
    let cart = await Cart.findOne({ user_id: req.params.userId });
    if (!cart) {
      cart = new Cart({ user_id: req.params.userId, restaurant_id: req.body.restaurant_id, items: [] });
    }
    cart.items.push({ menu_item_id: req.body.menu_item_id, quantity: req.body.quantity });
    cart.updated_at = Date.now();
    await cart.save();
    res.json(cart);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/cart/{userId}/remove/{itemId}:
 *   delete:
 *     summary: Remove item from cart
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: itemId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Item removed
 */
router.delete('/:userId/remove/:itemId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user_id: req.params.userId });
    cart.items = cart.items.filter(i => i._id.toString() !== req.params.itemId);
    await cart.save();
    res.json(cart);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;