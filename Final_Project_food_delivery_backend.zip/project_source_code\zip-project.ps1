# PowerShell script to zip the food delivery backend project.
# It places PROJECT_REPORT.md, README.md, and screenshots/ at the root of the ZIP,
# and puts all source code inside a 'project_source_code' subfolder.
# It excludes 'node_modules', '.env', and any existing zip files to keep the file small and secure.

$projectName = "food-delivery-backend"
$currentDir = (Get-Item .).FullName
$parentDir = (Get-Item .).Parent.FullName
$zipFile = Join-Path $parentDir "$projectName.zip"

Write-Host "Creating zip package: $projectName.zip"
Write-Host "Saving to: $zipFile"
Write-Host "Please wait..."

# Create a temporary staging directory in the parent folder
$tempDir = Join-Path $parentDir "food_delivery_temp_staging"
if (Test-Path $tempDir) { 
    Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $tempDir | Out-Null

# Create the nested directories inside staging
$sourceCodeStaging = Join-Path $tempDir "project_source_code"
$screenshotsStaging = Join-Path $tempDir "screenshots"

New-Item -ItemType Directory -Path $sourceCodeStaging | Out-Null
New-Item -ItemType Directory -Path $screenshotsStaging | Out-Null

# Copy project report to the root of the staging folder
if (Test-Path ".\PROJECT_REPORT.doc") {
    Copy-Item -Path ".\PROJECT_REPORT.doc" -Destination $tempDir -Force
}

# Copy README.md to the root of the staging folder
if (Test-Path ".\README.md") {
    Copy-Item -Path ".\README.md" -Destination $tempDir -Force
}

# Copy screenshots folder contents to root/screenshots of the staging folder
if (Test-Path ".\screenshots") {
    Copy-Item -Path ".\screenshots\*" -Destination $screenshotsStaging -Recurse -Force -ErrorAction SilentlyContinue
}

# Find and copy all source files and folders into root/project_source_code of staging folder
Get-ChildItem -Path . -Recurse | Where-Object {
    # Exclude node_modules, local env file, existing zip files
    $_.FullName -notmatch "node_modules" -and 
    $_.FullName -notmatch "\\\.env$" -and 
    $_.FullName -notmatch "\.zip$" -and
    # Exclude all project report files, folders, pdfs, readmes, and screenshots from the source code folder
    $_.FullName -notmatch "PROJECT_REPORT" -and
    $_.FullName -notmatch "\.pdf$" -and
    $_.FullName -notmatch "README\.md$" -and
    $_.FullName -notmatch "screenshots"
} | ForEach-Object {
    $destinationPath = $_.FullName.Replace($currentDir, $sourceCodeStaging)
    if ($_.PSIsContainer) {
        if (-not (Test-Path $destinationPath)) {
            New-Item -ItemType Directory -Path $destinationPath | Out-Null
        }
    } else {
        $parentPath = Split-Path $destinationPath
        if (-not (Test-Path $parentPath)) {
            New-Item -ItemType Directory -Path $parentPath | Out-Null
        }
        Copy-Item -Path $_.FullName -Destination $destinationPath -Force
    }
}

# Zip the staged files
if (Test-Path $zipFile) { 
    Remove-Item $zipFile -Force 
}
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipFile -Force

# Clean up the staging folder
Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Done! Your project is packaged into: $zipFile" -ForegroundColor Green
Write-Host "You can find it on your Desktop." -ForegroundColor Green
