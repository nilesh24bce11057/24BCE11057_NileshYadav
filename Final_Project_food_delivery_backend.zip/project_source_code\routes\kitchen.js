const express = require('express');
const router = express.Router();
const KitchenOrder = require('../models/KitchenOrder');

/**
 * @swagger
 * /api/kitchen/{restaurantId}/queue:
 *   get:
 *     summary: Get kitchen queue for a restaurant
 *     parameters:
 *       - in: path
 *         name: restaurantId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Kitchen queue
 */
router.get('/:restaurantId/queue', async (req, res) => {
  try {
    const queue = await KitchenOrder.find({ restaurant_id: req.params.restaurantId })
      .populate('order_id').populate('items.menu_item_id');
    res.json(queue);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/kitchen:
 *   post:
 *     summary: Create a kitchen order
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               order_id:
 *                 type: string
 *               restaurant_id:
 *                 type: string
 *               items:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     menu_item_id:
 *                       type: string
 *                     status:
 *                       type: string
 *                       enum: ['pending', 'cooking', 'ready']
 *               assigned_chef:
 *                 type: string
 *     responses:
 *       201:
 *         description: Kitchen order created
 */
router.post('/', async (req, res) => {
  try {
    const kitchenOrder = new KitchenOrder(req.body);
    await kitchenOrder.save();
    res.status(201).json(kitchenOrder);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/kitchen/{orderId}/status:
 *   put:
 *     summary: Update kitchen order status
 *     parameters:
 *       - in: path
 *         name: orderId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Status updated
 */
router.put('/:orderId/status', async (req, res) => {
  try {
    const kitchenOrder = await KitchenOrder.findByIdAndUpdate(req.params.orderId, req.body, { new: true });
    res.json(kitchenOrder);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

module.exports = router;