const express = require('express');
const router = express.Router();
const DeliveryAgent = require('../models/DeliveryAgent');

/**
 * @swagger
 * /api/delivery-agents:
 *   get:
 *     summary: Get all delivery agents
 *     responses:
 *       200:
 *         description: List of agents
 */
router.get('/', async (req, res) => {
  try {
    const agents = await DeliveryAgent.find().populate('current_order_id');
    res.json(agents);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/delivery-agents:
 *   post:
 *     summary: Add a delivery agent
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               phone:
 *                 type: string
 *               vehicle_type:
 *                 type: string
 *                 enum: ['bike', 'scooter', 'cycle']
 *               is_available:
 *                 type: boolean
 *     responses:
 *       201:
 *         description: Agent added
 */
router.post('/', async (req, res) => {
  try {
    const agent = new DeliveryAgent(req.body);
    await agent.save();
    res.status(201).json(agent);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/delivery-agents/available:
 *   get:
 *     summary: Get available delivery agents
 *     responses:
 *       200:
 *         description: Available agents
 */
router.get('/available', async (req, res) => {
  try {
    const agents = await DeliveryAgent.find({ is_available: true });
    res.json(agents);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/delivery-agents/{id}:
 *   put:
 *     summary: Update delivery agent
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Agent updated
 *   delete:
 *     summary: Delete delivery agent
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Agent deleted
 */
router.put('/:id', async (req, res) => {
  try {
    const agent = await DeliveryAgent.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(agent);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await DeliveryAgent.findByIdAndDelete(req.params.id);
    res.json({ message: 'Agent deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;