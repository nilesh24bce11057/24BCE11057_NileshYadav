const express = require('express');
const router = express.Router();
const Offer = require('../models/Offer');

/**
 * @swagger
 * /api/offers:
 *   get:
 *     summary: Get all offers
 *     responses:
 *       200:
 *         description: List of offers
 */
router.get('/', async (req, res) => {
  try {
    const offers = await Offer.find().populate('restaurant_id');
    res.json(offers);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/offers:
 *   post:
 *     summary: Create an offer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               code:
 *                 type: string
 *               description:
 *                 type: string
 *               discount_pct:
 *                 type: number
 *               restaurant_id:
 *                 type: string
 *               valid_until:
 *                 type: string
 *     responses:
 *       201:
 *         description: Offer created
 */
router.post('/', async (req, res) => {
  try {
    const offer = new Offer(req.body);
    await offer.save();
    res.status(201).json(offer);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/offers/apply:
 *   post:
 *     summary: Apply a coupon code
 *     responses:
 *       200:
 *         description: Offer applied
 */
router.post('/apply', async (req, res) => {
  try {
    const offer = await Offer.findOne({ code: req.body.code });
    if (!offer) return res.status(404).json({ message: 'Invalid coupon code' });
    if (offer.valid_until && offer.valid_until < new Date()) {
      return res.status(400).json({ message: 'Coupon expired' });
    }
    res.json({ message: 'Offer applied', discount_pct: offer.discount_pct });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;