const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true 
  },
  description: { 
    type: String 
  },
  menu_items: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'MenuItem' 
  }]
}, { timestamps: true });

module.exports = mongoose.model('Category', categorySchema);