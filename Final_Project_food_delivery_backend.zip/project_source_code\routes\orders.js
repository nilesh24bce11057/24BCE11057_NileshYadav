const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const User = require('../models/User');

/**
 * @swagger
 * /api/orders:
 *   get:
 *     summary: Get all orders
 *     responses:
 *       200:
 *         description: List of orders
 */
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find().populate('user_id').populate('restaurant_id').populate('items.menu_item_id');
    res.json(orders);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/orders/{id}:
 *   get:
 *     summary: Get order by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Order details
 */
router.get('/:id', async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('user_id').populate('restaurant_id').populate('items.menu_item_id');
    res.json(order);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/orders/checkout/{userId}:
 *   post:
 *     summary: Checkout cart and place order
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               total_amount:
 *                 type: number
 *               payment_mode:
 *                 type: string
 *                 enum: ['cash', 'online', 'card']
 *     responses:
 *       201:
 *         description: Order placed
 */
router.post('/checkout/:userId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user_id: req.params.userId });
    if (!cart) return res.status(404).json({ message: 'Cart is empty' });
    const order = new Order({
      user_id: req.params.userId,
      restaurant_id: cart.restaurant_id,
      items: cart.items.map(i => ({ menu_item_id: i.menu_item_id, quantity: i.quantity, price: 0 })),
      total_amount: req.body.total_amount,
      payment_mode: req.body.payment_mode
    });
    await order.save();
    await User.findByIdAndUpdate(req.params.userId, { $push: { order_history: order._id } });
    await Cart.findOneAndDelete({ user_id: req.params.userId });
    res.status(201).json(order);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/orders/{id}/status:
 *   put:
 *     summary: Update order status
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Status updated
 */
router.put('/:id/status', async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
    res.json(order);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

module.exports = router;