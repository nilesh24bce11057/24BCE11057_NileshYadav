const mongoose = require('mongoose');

const restaurantSchema = new mongoose.Schema({
  name:         { type: String, required: true },
  cuisine_type: { type: String, required: true },
  address:      { type: String, required: true },
  rating:       { type: Number, default: 0 },
  owner_id:     { type: mongoose.Schema.Types.ObjectId, ref: 'User' },      // One to One
  locality_id:  { type: mongoose.Schema.Types.ObjectId, ref: 'Locality' },  // Many to One
  menu_items:   [{ type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem' }] // One to Many
}, { timestamps: true });

module.exports = mongoose.model('Restaurant', restaurantSchema);