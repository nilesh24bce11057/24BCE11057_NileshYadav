const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
  restaurant_id:      { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
  ingredient_name:    { type: String, required: true },
  quantity_available: { type: Number, required: true },
  unit:               { type: String, enum: ['kg', 'litres', 'pieces'], required: true },
  reorder_level:      { type: Number, required: true },
  linked_menu_items:  [{ type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem' }] // Many to Many
}, { timestamps: true });

module.exports = mongoose.model('Inventory', inventorySchema);