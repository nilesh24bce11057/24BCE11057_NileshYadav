const express = require('express');
const router = express.Router();
const Locality = require('../models/Locality');

/**
 * @swagger
 * /api/localities:
 *   get:
 *     summary: Get all localities
 *     responses:
 *       200:
 *         description: List of localities
 */
router.get('/', async (req, res) => {
  try {
    const localities = await Locality.find().populate('restaurants');
    res.json(localities);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/localities:
 *   post:
 *     summary: Add a locality
 *     responses:
 *       201:
 *         description: Locality added
 */
router.post('/', async (req, res) => {
  try {
    const locality = new Locality(req.body);
    await locality.save();
    res.status(201).json(locality);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

/**
 * @swagger
 * /api/localities:
 *   post:
 *     summary: Add a locality
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               area_name:
 *                 type: string
 *               pincode:
 *                 type: string
 *               city:
 *                 type: string
 *     responses:
 *       201:
 *         description: Locality added
 */
router.get('/:pincode', async (req, res) => {
  try {
    const locality = await Locality.findOne({ pincode: req.params.pincode }).populate('restaurants');
    res.json(locality);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;