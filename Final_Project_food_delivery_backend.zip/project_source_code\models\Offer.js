const mongoose = require('mongoose');

const offerSchema = new mongoose.Schema({
  code:          { type: String, required: true, unique: true },
  description:   { type: String },
  discount_pct:  { type: Number, required: true },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' },
  valid_until:   { type: Date },
  users_used:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }] // Many to Many
}, { timestamps: true });

module.exports = mongoose.model('Offer', offerSchema);