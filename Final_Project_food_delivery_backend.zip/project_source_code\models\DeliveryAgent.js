const mongoose = require('mongoose');

const deliveryAgentSchema = new mongoose.Schema({
  name:             { type: String, required: true },
  phone:            { type: String, required: true },
  vehicle_type:     { type: String, enum: ['bike', 'scooter', 'cycle'] },
  is_available:     { type: Boolean, default: true },
  current_order_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Order' }, // One to One
  completed_orders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Order' }]
}, { timestamps: true });

module.exports = mongoose.model('DeliveryAgent', deliveryAgentSchema);