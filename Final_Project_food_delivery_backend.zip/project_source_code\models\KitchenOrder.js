const mongoose = require('mongoose');

const kitchenOrderSchema = new mongoose.Schema({
  order_id:      { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
  items: [{
    menu_item_id: { type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem' },
    status: { type: String, enum: ['pending', 'cooking', 'ready'], default: 'pending' }
  }],
  assigned_chef: { type: String },
  started_at:    { type: Date },
  ready_at:      { type: Date }
}, { timestamps: true });

module.exports = mongoose.model('KitchenOrder', kitchenOrderSchema);