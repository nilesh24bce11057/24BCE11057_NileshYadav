const mongoose = require('mongoose');

const cartSchema = new mongoose.Schema({
  user_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true,
    unique: true 
  },
  restaurant_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Restaurant' 
  },
  items: [{
    menu_item_id: { 
      type: mongoose.Schema.Types.ObjectId, 
      ref: 'MenuItem', 
      required: true 
    },
    quantity: { 
      type: Number, 
      required: true, 
      default: 1 
    }
  }],
  updated_at: { 
    type: Date, 
    default: Date.now 
  }
}, { timestamps: true });

module.exports = mongoose.model('Cart', cartSchema);