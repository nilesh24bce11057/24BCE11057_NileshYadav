# PowerShell script to zip the food delivery backend project.
# It excludes 'node_modules', '.env', and any existing zip files to keep the file small and secure.

$projectName = "food-delivery-backend"
$currentDir = (Get-Item .).FullName
$parentDir = (Get-Item .).Parent.FullName
$zipFile = Join-Path $parentDir "$projectName.zip"

Write-Host "Creating zip package: $projectName.zip"
Write-Host "Saving to: $zipFile"
Write-Host "Please wait..."

# Create a temporary staging directory in the parent folder
$tempDir = Join-Path $parentDir "food_delivery_temp_staging"
if (Test-Path $tempDir) { 
    Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $tempDir | Out-Null

# Find and copy all files and folders excluding node_modules and .env
Get-ChildItem -Path . -Recurse | Where-Object {
    $_.FullName -notmatch "node_modules" -and $_.FullName -notmatch "\\\.env$" -and $_.FullName -notmatch "\.zip$"
} | ForEach-Object {
    $destinationPath = $_.FullName.Replace($currentDir, $tempDir)
    if ($_.PSIsContainer) {
        if (-not (Test-Path $destinationPath)) {
            New-Item -ItemType Directory -Path $destinationPath | Out-Null
        }
    } else {
        $parentPath = Split-Path $destinationPath
        if (-not (Test-Path $parentPath)) {
            New-Item -ItemType Directory -Path $parentPath | Out-Null
        }
        Copy-Item -Path $_.FullName -Destination $destinationPath -Force
    }
}

# Zip the staged files
if (Test-Path $zipFile) { 
    Remove-Item $zipFile -Force 
}
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipFile -Force

# Clean up the staging folder
Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Done! Your project is packaged into: $zipFile" -ForegroundColor Green
Write-Host "You can find it on your Desktop." -ForegroundColor Green
